interface Params {
  data: User[];
  filter: string;
}
