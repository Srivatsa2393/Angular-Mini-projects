import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../services/login.service';
import { config } from '../config';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public errorMessage = '';

  constructor(private loginService: LoginService, private router: Router) { }

  ngOnInit() {
    console.log('Login process');
  }

  login(e) {
    e.preventDefault();
    console.log(e);

    var username = e.target.elements[0].value;
    var password = e.target.elements[1].value;
    var key = btoa(btoa(username) + '??' + btoa(password))

    console.log(username, password);
    console.log(key);
    document.cookie = "sessionID="+key+';';

    if(username === config.username && password === config.password){
      this.loginService.setUserLoggedIn();
      this.router.navigate(['deviceInfo'])
    }else if(username !== 'user3' && password !== 'user3'){
      this.errorMessage = 'Failed to login, please try again';
    }
  }

}
