import { Injectable } from '@angular/core';

@Injectable()
export class LoginService {

  private isLoggedIn;
  private username;

  constructor() { 
    this.isLoggedIn = false;
  }

  setUserLoggedIn() {
    this.isLoggedIn = true;
    this.username = 'user3';
  }

  getUserLoggedIn() {
    return this.isLoggedIn;
  }


}
