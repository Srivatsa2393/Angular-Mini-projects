export class xmldata{
    data : string
}